import random, sys
from copy import deepcopy
from typing import Literal
from abc import ABC, abstractmethod
from exceptions import AgentException
from heuristics import simple_score, advanced_score
from connect4 import Connect4


class Agent(ABC):
    def __init__(self, my_token="o", **kwargs):
        self.my_token = my_token

    @abstractmethod
    def decide(self, connect4):
        pass

    def __str__(self):
        return f"{self.my_token} ({self.__class__.__name__})"


class RandomAgent(Agent):
    def __init__(self, my_token="o", **kwargs):
        super().__init__(my_token, **kwargs)

    def decide(self, connect4):
        if connect4.who_moves != self.my_token:
            raise AgentException("not my round")
        return random.choice(connect4.possible_moves())


class MinMaxAgent(Agent):
    def __init__(
        self, my_token="o", depth=4, heuristic: Literal["simple", "advanced"] = "simple"
    ):
        super().__init__(my_token)
        self.depth = depth
        self.heuristic = heuristic
        self.heuristic_fun = simple_score if heuristic == "simple" else advanced_score

    def __str__(self):
        return f"{self.my_token} ({self.__class__.__name__}+{self.heuristic})"

    def decide(self, connect4):
        if connect4.who_moves != self.my_token:
            raise AgentException("not my round")

        best_move, best_score = self.minmax(connect4, depth=self.depth)
        return best_move

    def minmax(self, connect4: Connect4, depth=4, maximizing=True):

        # TODO

        raise NotImplementedError()


class AlphaBetaAgent(MinMaxAgent):
    def __init__(
        self, my_token="o", depth=4, heuristic: Literal["simple", "advanced"] = "simple"
    ):
        super().__init__(my_token)
        self.depth = depth
        self.heuristic = heuristic
        self.heuristic_fun = simple_score if heuristic == "simple" else advanced_score

    def decide(self, connect4):
        if connect4.who_moves != self.my_token:
            raise AgentException("not my round")

        best_move, best_score = self.alphabeta(connect4, depth=self.depth)
        return best_move

    def alphabeta(
        self,
        connect4: Connect4,
        depth=4,
        maximizing=True,
        alpha=-sys.maxsize,
        beta=sys.maxsize,
    ):
        # TODO

        raise NotImplementedError()
